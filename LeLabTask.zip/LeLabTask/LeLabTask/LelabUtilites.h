//
//  LelabUtilites.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface LelabUtilites : NSObject

+(UIColor *)colorWithHexString:(NSString*)hex;
+(BOOL)chekIphoneNewModelOrOld;
+(void)tostMessage:(NSString *)alertmesssage fromViewController:(UIViewController *)controller;
+(CGFloat)getLabelHeight:(CGSize)labelSize string: (NSString *)string font: (UIFont *)font;
+(CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font;
+(void)emailToUser:(NSString *)email_id;
+(void)callToUser:(NSString *)mobileNumber;

@end

NS_ASSUME_NONNULL_END
