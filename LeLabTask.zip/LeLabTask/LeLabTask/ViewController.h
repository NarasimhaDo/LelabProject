//
//  ViewController.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 07/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LelabContstsnts.h"


@interface ViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    LelabMainHederView *headerView;
}
@property (nonatomic,retain) UITableView *listTableView;
@property (nonatomic,retain) NSMutableArray *listArray;
@property (nonatomic,retain) UIView *ActivityView;
@property (nonatomic,retain) UIActivityIndicatorView *activityLoaderObj;
@end

