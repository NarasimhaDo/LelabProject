//
//  SceneDelegate.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 07/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

