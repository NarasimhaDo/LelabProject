//
//  LelabContstsnts.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#ifndef LelabContstsnts_h
#define LelabContstsnts_h

#define Max_Width [[UIScreen mainScreen] bounds].size.width
#define Max_Height [[UIScreen mainScreen] bounds].size.height

// define statc values

#define noInternet @"No Internet"
#define TimeUp @"Time out"
#define Diconnect @"Connection Disconnected"
#define NoSuccess @"false"
#define NetworkSuccess @"true"

#define list_title_key @"List"
#define info_title_key @"Info"
#define tablevviewCell_height 70
#define cell_identifier @"mycell"

#define name_key @"name"
#define user_name_key @"username"
#define email_key @"email"
#define phone_key @"phone"
#define website_key @"website"
#define company_key @"company"
#define geo_key @"geo"
#define lat_key @"lat"
#define lag_key @"lng"
#define street_key @"street"
#define suite_key @"suite"
#define city_key @"city"
#define zip_code_key @"zipcode"
#define address_key @"address"
#define headerColor @"0067A9"


// fonts

#define poppinssemobold @"Poppins-SemiBold"
#define poppinsRegular @"Poppins-Regular"
#define palatinoItalic @"PalatinoLinotype-Italic"


// define calls names

#import "LelabNetworkserviceClass.h"
#import "LelabUtilites.h"
#import "LelabProfileView.h"
#import "LelabMainHederView.h"
#import "CustomTableViewCell.h"


// url constants
#define fetch_url @"https://jsonplaceholder.typicode.com/users"
#define Get_method @"GET"
#define success_key @"success"
#define is_true @"true"
#define is_false @"false"
#define errorMessage @"Oops...!Something Went Wrong."
#define linkErrorMessage @"Invalid URL"
#define StoreContact_key @"storeContacts"

#define auth_key @"Bearer bc032b8ba33c24cd7e1dbb4b88af6755e9df84484ae68892a0080912fd89f5080fb9e62e99f2590f876f44c2d9ad8f232877627fc507fc30d9049e010da314cd"

#endif /* LelabContstsnts_h */
