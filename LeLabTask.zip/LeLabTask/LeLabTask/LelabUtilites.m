//
//  LelabUtilites.m
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import "LelabUtilites.h"

@implementation LelabUtilites


// add custom color
+(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return [UIColor grayColor];
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}
// check the iphone modal new or old
+(BOOL)chekIphoneNewModelOrOld
{
    BOOL is_new = NO;
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        switch ((int)[[UIScreen mainScreen] nativeBounds].size.height) {
            case 1136:
                is_new = NO; // 5s
                break;
            case 1334:
                is_new = NO;
                //                printf("iPhone 6/6S/7/8");
                break;
                
            case 1920:
                is_new = NO;
                //                printf("iPhone 6+/6S+/7+/8+");
                break;
            case 2208:
                is_new = NO;
                break;
            case 2436:
                is_new = YES;
                //                print("iPhone X/XS/11 Pro");
                break;
            case 2688:
                is_new = YES;
                //                print("iPhone XS Max/11 Pro Max");
                break;
                
            case 1792:
                is_new = YES;
                //                print("iPhone XR/ 11 ");
                break;
            default:
                is_new = NO;
                //                printf("Unknown");
                break;
        }
    }
    return is_new;
}
// alert message
+(void)tostMessage:(NSString *)alertmesssage fromViewController:(UIViewController *)controller
{
    @try{
        if (controller != nil) {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            if (alertmesssage.length !=0 || [alertmesssage length] !=0 || alertmesssage ==[NSNull class] || alertmesssage == nil || alertmesssage != '\0'){
                alertmesssage =alertmesssage;
            }else{
                alertmesssage =@"Please try after some time";
            }
            NSMutableAttributedString *hogan = [[NSMutableAttributedString alloc] initWithString:alertmesssage];
            [hogan addAttribute:NSFontAttributeName
                          value:[UIFont fontWithName:@"Arial" size:25.0]
                          range:NSMakeRange(45, 0)];
            [alertController setValue:hogan forKey:@"attributedMessage"];
            controller.modalPresentationStyle = UIModalPresentationFullScreen;
            dispatch_async(dispatch_get_main_queue(), ^{
                [controller presentViewController:alertController animated:YES completion:nil];
            });
            if ([alertmesssage isEqualToString:@"Please enter minimum 3 characters to search"]) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [alertController dismissViewControllerAnimated:YES completion:^{
                    }];
                });
            }else{
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [alertController dismissViewControllerAnimated:YES completion:^{
                    }];
                });
            }
        }
    }@catch(NSException *exception){
        
    }
}
// gel lable height based on string
+(CGFloat)getLabelHeight:(CGSize)labelSize string: (NSString *)string font: (UIFont *)font{
    CGSize size;
    NSStringDrawingContext *context = [[NSStringDrawingContext alloc] init];
    
    CGSize boundingBox = [string boundingRectWithSize:labelSize options:NSStringDrawingUsesLineFragmentOrigin
                                           attributes:@{NSFontAttributeName:font} context:context].size;
    size = CGSizeMake(ceil(boundingBox.width), ceil(boundingBox.height));
    return size.height;
}
// get width of string
+(CGFloat)widthOfString:(NSString *)string withFont:(UIFont *)font {
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
    if (string.length !=0)
    {
        return [[[NSAttributedString alloc] initWithString:string attributes:attributes] size].width;
    }
    return 10;
    
}
// email to user
+(void)emailToUser:(NSString *)email_id
{
    NSString *recipients = [NSString stringWithFormat:@"mailto:%@?subject=%@",email_id,@""];//@"mailto:myemail@gmail.com?subject=subjecthere";
    NSString *body = @"";
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email] options:@{} completionHandler:^(BOOL success) {
        
    }];
}

// call to user
+(void)callToUser:(NSString *)mobileNumber
{
    NSURL *phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt:%@",mobileNumber]];
    
    if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
        //  [[UIApplication sharedApplication] openURL:phoneUrl];
        [[UIApplication sharedApplication]openURL:phoneUrl options:@{} completionHandler:nil];
        
    }
}


@end
