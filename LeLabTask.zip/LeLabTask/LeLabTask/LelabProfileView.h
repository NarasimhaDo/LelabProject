//
//  LelabProfileView.h
//  LeLabTask
//
//  Created by narasimhudu Duvvuru on 08/04/20.
//  Copyright © 2020 narasimhudu Duvvuru. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LelabContstsnts.h"


NS_ASSUME_NONNULL_BEGIN

@interface LelabProfileView : UIView
{
    int height ;
}

@property (nonatomic,retain) UIScrollView *background_scrollView;
@property (nonatomic,retain) NSMutableDictionary *profileDetails;
@property (nonatomic,retain) UIViewController *superController;
@property (nonatomic,retain) UIView *profileView;
@property (nonatomic,retain) UIView *background_layerView;
@property (nonatomic,retain) UILabel *name_label;
@property (nonatomic,retain) UILabel *email_label;
@property (nonatomic,retain) UILabel *phone_label;
@property (nonatomic,retain) UILabel *company_label;
@property (nonatomic,retain) UILabel *website_label;
@property (nonatomic,retain) UILabel *address_lable;

@property (nonatomic,retain) UIButton *email_button;
@property (nonatomic,retain) UIButton *phone_button;
@property (nonatomic,retain) UIButton *website_button;

-(void)showuserInfoView:(NSMutableDictionary *)dataDict withController:(UIViewController *)controller;



@end

NS_ASSUME_NONNULL_END
